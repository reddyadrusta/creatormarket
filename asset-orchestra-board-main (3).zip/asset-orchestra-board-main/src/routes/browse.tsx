import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { creators } from "@/lib/data";
import { CreatorCard, PageHeader, inputCls } from "@/components/market";

export const Route = createFileRoute("/browse")({
  head: () => ({ meta: [
    { title: "Browse AI creators — Creator Market" },
    { name: "description", content: "Find verified AI filmmakers, generative artists, animators and sound designers." },
    { property: "og:title", content: "Browse AI creators — Creator Market" },
    { property: "og:description", content: "Verified AI-native talent vetted for tools and workflows." },
  ] }),
  component: Browse,
});

function Browse() {
  const [q, setQ] = useState(""); const [spec, setSpec] = useState(""); const [verified, setVerified] = useState(false); const [sort, setSort] = useState("rating");
  const specs = [...new Set(creators.flatMap((c) => c.specialties))];
  let list = creators.filter((c) => (!q || [c.name, c.title, c.location, ...c.tools].join(" ").toLowerCase().includes(q.toLowerCase())) && (!spec || c.specialties.includes(spec)) && (!verified || c.verified));
  list = [...list].sort((a, b) => sort === "rate" ? a.rate - b.rate : sort === "followers" ? b.followers - a.followers : b.rating - a.rating);
  return (
    <>
      <PageHeader title="Creators" sub="Top-rated AI-native talent, vetted for tools and workflows." />
      <div className="mx-auto max-w-7xl px-5 py-10">
        <div className="mb-6 flex flex-wrap gap-3">
          <input className={`${inputCls} max-w-xs`} placeholder="Search name, tool, city…" value={q} onChange={(e) => setQ(e.target.value)} />
          <select className={`${inputCls} w-auto`} value={spec} onChange={(e) => setSpec(e.target.value)}><option value="">All specialties</option>{specs.map((s) => <option key={s}>{s}</option>)}</select>
          <select className={`${inputCls} w-auto`} value={sort} onChange={(e) => setSort(e.target.value)}><option value="rating">Top rated</option><option value="followers">Most followed</option><option value="rate">Lowest rate</option></select>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} />Verified only</label>
        </div>
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{list.map((c) => <CreatorCard key={c.id} c={c} />)}</div>
        {!list.length && <p className="py-20 text-center text-muted-foreground">No creators found.</p>}
      </div>
    </>
  );
}
