import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CATEGORIES, MOODS, getCreator, works, type WorkType } from "@/lib/data";
import { PageHeader, WorkCard, inputCls } from "@/components/market";

type S = { q?: string; type?: string; sort?: string; pricing?: string; mood?: string; license?: string };

export const Route = createFileRoute("/explore")({
  validateSearch: (s: Record<string, unknown>): S => ({
    q: s.q ? String(s.q) : undefined, type: s.type ? String(s.type) : undefined, sort: s.sort ? String(s.sort) : undefined,
    pricing: s.pricing ? String(s.pricing) : undefined, mood: s.mood ? String(s.mood) : undefined, license: s.license ? String(s.license) : undefined,
  }),
  head: () => ({ meta: [
    { title: "Explore AI artwork by mood & category — Creator Market" },
    { name: "description", content: "Filter AI film, art, animation, 3D and audio by mood, price and license." },
    { property: "og:title", content: "Explore AI artwork — Creator Market" },
    { property: "og:description", content: "Filter generative works by mood, category, price and license." },
  ] }),
  component: Explore,
});

function Explore() {
  const s = Route.useSearch();
  const nav = useNavigate({ from: "/explore" });
  const set = (patch: Partial<S>) => nav({ search: (p: S) => ({ ...p, ...patch }) });
  let list = works.filter((w) => {
    const c = getCreator(w.creatorId)!;
    if (s.type && w.type !== (s.type as WorkType)) return false;
    if (s.pricing === "free" && w.price !== 0) return false;
    if (s.pricing === "premium" && w.price === 0) return false;
    if (s.mood && !w.tags.includes(s.mood)) return false;
    if (s.license === "commercial" && !w.commercial) return false;
    if (s.q) { const q = s.q.toLowerCase(); if (![w.title, c.name, ...w.tags, w.type].join(" ").toLowerCase().includes(q)) return false; }
    return true;
  });
  if (s.sort === "newest") list = [...list].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  else if (s.sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
  else if (s.sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
  else list = [...list].sort((a, b) => b.views - a.views);
  return (
    <>
      <PageHeader title="Explore works" sub="Filter by mood, category, price and license." />
      <div className="mx-auto grid max-w-7xl gap-8 px-5 py-10 lg:grid-cols-[240px_1fr]">
        <aside className="space-y-6">
          <input className={inputCls} placeholder="Search…" defaultValue={s.q} onKeyDown={(e) => e.key === "Enter" && set({ q: (e.target as HTMLInputElement).value || undefined })} />
          <div><h4 className="mb-2 text-sm font-semibold">Category</h4><div className="flex flex-wrap gap-1.5">
            <Chip on={!s.type} onClick={() => set({ type: undefined })}>All</Chip>
            {CATEGORIES.map((c) => <Chip key={c.type} on={s.type === c.type} onClick={() => set({ type: c.type })}>{c.label}</Chip>)}
          </div></div>
          <div><h4 className="mb-2 text-sm font-semibold">Mood</h4><div className="flex flex-wrap gap-1.5">
            {MOODS.map((m) => <Chip key={m} on={s.mood === m} onClick={() => set({ mood: s.mood === m ? undefined : m })}>{m}</Chip>)}
          </div></div>
          <div><h4 className="mb-2 text-sm font-semibold">Pricing</h4><div className="flex flex-wrap gap-1.5">
            {[["", "All"], ["free", "Free"], ["premium", "Premium"]].map(([v, l]) => <Chip key={l} on={(s.pricing ?? "") === v} onClick={() => set({ pricing: v || undefined })}>{l}</Chip>)}
          </div></div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={s.license === "commercial"} onChange={(e) => set({ license: e.target.checked ? "commercial" : undefined })} />Commercial use only</label>
          <button className="text-sm text-primary hover:underline" onClick={() => nav({ search: {} })}>Clear all filters</button>
        </aside>
        <div>
          <div className="mb-5 flex items-center justify-between"><p className="text-sm text-muted-foreground">{list.length} works</p>
            <select className={`${inputCls} w-auto`} value={s.sort ?? "trending"} onChange={(e) => set({ sort: e.target.value })}>
              <option value="trending">Trending</option><option value="newest">Newest</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option>
            </select></div>
          {list.length ? <div className="grid grid-cols-2 gap-5 md:grid-cols-3">{list.map((w) => <WorkCard key={w.id} work={w} />)}</div> : <p className="py-20 text-center text-muted-foreground">No works match these filters.</p>}
        </div>
      </div>
    </>
  );
}

export function Chip({ on, onClick, children }: { on?: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button onClick={onClick} className={`rounded-full border px-3 py-1 text-xs transition ${on ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary"}`}>{children}</button>;
}
