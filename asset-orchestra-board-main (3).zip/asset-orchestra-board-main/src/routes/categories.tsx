import { createFileRoute, Link } from "@tanstack/react-router";
import { CATEGORIES, MOODS, works } from "@/lib/data";
import { Art, PageHeader } from "@/components/market";

export const Route = createFileRoute("/categories")({
  head: () => ({ meta: [
    { title: "Categories — Creator Market" },
    { name: "description", content: "Browse AI film, animation, generative art, 3D, motion and AI audio." },
    { property: "og:title", content: "Categories — Creator Market" },
    { property: "og:description", content: "Every format of AI-native creative work." },
  ] }),
  component: Categories,
});

function Categories() {
  return (
    <>
      <PageHeader title="Categories" sub="Every format of AI-native creative work." />
      <div className="mx-auto max-w-7xl px-5 py-10">
        <div className="grid gap-5 md:grid-cols-3">
          {CATEGORIES.map((c) => { const list = works.filter((w) => w.type === c.type); return (
            <Link key={c.type} to="/explore" search={{ type: c.type }} className="group overflow-hidden rounded-2xl border border-border bg-card">
              <Art hues={list[0]?.hues ?? [75, 30]} type={c.type} className="h-40 transition group-hover:opacity-90" />
              <div className="p-5"><h3 className="font-display text-xl font-semibold">{c.label}</h3><p className="text-sm text-muted-foreground">{c.blurb}</p><p className="mt-2 text-sm text-primary">{list.length} works →</p></div>
            </Link>); })}
        </div>
        <h2 className="mt-12 font-display text-2xl font-bold">Browse by mood</h2>
        <div className="mt-4 flex flex-wrap gap-2">{MOODS.map((m) => <Link key={m} to="/explore" search={{ mood: m }} className="rounded-full border border-border px-4 py-2 hover:border-primary hover:text-primary">{m}</Link>)}</div>
      </div>
    </>
  );
}
