import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useStore } from "@/lib/store";
import { btnCls, inputCls } from "@/components/market";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [
    { title: "Log in — Creator Market" },
    { name: "description", content: "Log in to manage licenses, briefs and moodboards." },
    { property: "og:title", content: "Log in — Creator Market" },
    { property: "og:description", content: "Access your Creator Market account." },
  ] }),
  component: Login,
});

function Login() {
  const { accounts, update } = useStore();
  const nav = useNavigate();
  const [email, setEmail] = useState(""); const [pw, setPw] = useState("");
  return (
    <div className="mx-auto max-w-sm px-5 py-20">
      <h1 className="font-display text-3xl font-bold">Welcome back</h1>
      <form className="mt-6 space-y-3" onSubmit={(e) => {
        e.preventDefault();
        const a = accounts.find((x) => x.email.toLowerCase() === email.toLowerCase() && x.password === pw);
        if (!a) return toast.error("Wrong email or password");
        update((s) => ({ ...s, user: { name: a.name, email: a.email, role: a.role } })); toast.success(`Welcome back, ${a.name}`); nav({ to: "/dashboard" });
      }}>
        <input required type="email" className={inputCls} placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input required type="password" className={inputCls} placeholder="Password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <button className={`${btnCls} w-full`}>Log in</button>
      </form>
      <p className="mt-4 text-sm text-muted-foreground">New here? <Link to="/register" className="text-primary">Create an account</Link></p>
    </div>
  );
}
