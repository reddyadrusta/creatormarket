import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { getCreator, getWork } from "@/lib/data";
import { useStore } from "@/lib/store";
import { PageHeader, RequireAuth, btnCls } from "@/components/market";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [
    { title: "Dashboard — Creator Market" },
    { name: "description", content: "Your licenses, briefs, proposals, moodboards and messages." },
    { property: "og:title", content: "Dashboard — Creator Market" },
    { property: "og:description", content: "Manage licensing and delivery." },
  ] }),
  component: () => <RequireAuth><Dashboard /></RequireAuth>,
});

const TABS = ["Licenses", "My briefs", "Proposals", "Following", "Messages"] as const;

function Dashboard() {
  const s = useStore();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Licenses");
  const spent = s.purchases.reduce((a, p) => a + p.price, 0);
  const mine = s.briefs.filter((b) => b.mine);
  return (
    <>
      <PageHeader title={`Hi, ${s.user!.name}`} sub={`${s.user!.role === "creator" ? "Creator" : "Buyer"} account · ${s.user!.email}`} />
      <div className="mx-auto max-w-7xl px-5 py-10">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
          {[["Licenses", s.purchases.length], ["Spent", `$${spent}`], ["Wishlist", s.wishlist.length], ["Moodboards", s.moodboards.length], ["Briefs posted", mine.length]].map(([k, v]) => (
            <div key={k} className="rounded-2xl border border-border bg-card p-4"><div className="text-sm text-muted-foreground">{k}</div><div className="mt-1 font-display text-3xl font-bold">{v}</div></div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap gap-2 border-b border-border">{TABS.map((t) => <button key={t} onClick={() => setTab(t)} className={`-mb-px border-b-2 px-4 py-2 text-sm ${tab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground"}`}>{t}</button>)}</div>
        <div className="mt-6 space-y-3">
          {tab === "Licenses" && (s.purchases.length ? s.purchases.map((p) => { const w = getWork(p.workId)!; return (
            <Link key={p.id} to="/work/$id" params={{ id: w.id }} className="flex justify-between rounded-xl border border-border bg-card p-4 hover:border-primary"><span>{w.title} <span className="text-sm capitalize text-muted-foreground">· {p.license}</span></span><span className="text-sm">{p.price ? `$${p.price}` : "Free"} · {p.date}</span></Link>); })
            : <Empty text="No licenses yet." to="/explore" cta="Explore works" />)}
          {tab === "My briefs" && (mine.length ? mine.map((b) => <div key={b.id} className="flex justify-between rounded-xl border border-border bg-card p-4"><span>{b.title}</span><span className="text-sm text-muted-foreground">{b.proposals} proposals · ${b.budget}</span></div>) : <Empty text="No briefs posted." to="/briefs/new" cta="Build a brief" />)}
          {tab === "Proposals" && (s.proposals.length ? s.proposals.map((p) => <div key={p.id} className="rounded-xl border border-border bg-card p-4"><div className="font-semibold">{s.briefs.find((b) => b.id === p.briefId)?.title ?? "Closed brief"} · ${p.price}</div><p className="text-sm text-muted-foreground">{p.message}</p></div>) : <Empty text="No proposals sent." to="/briefs" cta="See open briefs" />)}
          {tab === "Following" && (s.following.length ? s.following.map((id) => { const c = getCreator(id)!; return <Link key={id} to="/creator/$id" params={{ id }} className="block rounded-xl border border-border bg-card p-4 hover:border-primary">{c.name} <span className="text-sm text-muted-foreground">· {c.title}</span></Link>; }) : <Empty text="Not following anyone." to="/browse" cta="Browse creators" />)}
          {tab === "Messages" && (s.messages.length ? s.messages.map((m) => <div key={m.id} className="rounded-xl border border-border bg-card p-4"><div className="text-sm text-muted-foreground">To {getCreator(m.creatorId)?.name} · {m.date}</div><p>{m.text}</p></div>) : <Empty text="No messages yet." to="/browse" cta="Contact a creator" />)}
        </div>
      </div>
    </>
  );
}

function Empty({ text, to, cta }: { text: string; to: string; cta: string }) {
  return <div className="py-10 text-center"><p className="text-muted-foreground">{text}</p><Link to={to} className={`${btnCls} mt-3`}>{cta}</Link></div>;
}
