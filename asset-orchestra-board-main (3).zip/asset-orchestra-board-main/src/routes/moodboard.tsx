import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2, X } from "lucide-react";
import { getWork, works } from "@/lib/data";
import { useStore, uid } from "@/lib/store";
import { Art, PageHeader, btnCls, btnGhost, inputCls } from "@/components/market";

export const Route = createFileRoute("/moodboard")({
  head: () => ({ meta: [
    { title: "Moodboard Studio — Creator Market" },
    { name: "description", content: "Collect AI artwork references into moodboards for your next brief." },
    { property: "og:title", content: "Moodboard Studio — Creator Market" },
    { property: "og:description", content: "Build reference boards from AI artwork." },
  ] }),
  component: Moodboard,
});

function Moodboard() {
  const { moodboards, update } = useStore();
  const [active, setActive] = useState(moodboards[0]?.id ?? "");
  const [name, setName] = useState("");
  const board = moodboards.find((m) => m.id === active) ?? moodboards[0];
  const patch = (fn: (m: typeof board) => typeof board) => update((s) => ({ ...s, moodboards: s.moodboards.map((m) => (m.id === board.id ? fn(m) : m)) }));
  return (
    <>
      <PageHeader title="Moodboard Studio" sub="Gather references, annotate, and share direction with creators." />
      <div className="mx-auto grid max-w-7xl gap-8 px-5 py-10 lg:grid-cols-[240px_1fr]">
        <aside className="space-y-2">
          {moodboards.map((m) => <button key={m.id} onClick={() => setActive(m.id)} className={`block w-full rounded-lg px-3 py-2 text-left text-sm ${board?.id === m.id ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`}>{m.name} <span className="opacity-60">({m.workIds.length})</span></button>)}
          <form className="flex gap-2 pt-3" onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return; const id = uid(); update((s) => ({ ...s, moodboards: [...s.moodboards, { id, name, workIds: [], notes: "" }] })); setActive(id); setName(""); toast.success("Board created"); }}>
            <input className={inputCls} placeholder="New board…" value={name} onChange={(e) => setName(e.target.value)} /><button className={btnCls}>+</button>
          </form>
        </aside>
        {board ? (
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <input className={`${inputCls} max-w-sm font-display text-xl`} value={board.name} onChange={(e) => patch((m) => ({ ...m, name: e.target.value }))} />
              <button className={btnGhost} onClick={() => { navigator.clipboard?.writeText(`${board.name}: ${board.workIds.map((id) => getWork(id)?.title).join(", ")}`); toast.success("Board summary copied"); }}>Share</button>
              {moodboards.length > 1 && <button className={btnGhost} onClick={() => { update((s) => ({ ...s, moodboards: s.moodboards.filter((m) => m.id !== board.id) })); setActive(""); }}><Trash2 className="h-4 w-4" />Delete</button>}
            </div>
            <textarea className={`${inputCls} mt-4`} rows={3} placeholder="Notes: palette, references, pacing…" value={board.notes} onChange={(e) => patch((m) => ({ ...m, notes: e.target.value }))} />
            <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
              {board.workIds.map((id) => { const w = getWork(id)!; return (
                <div key={id} className="group relative">
                  <Link to="/work/$id" params={{ id }}><Art hues={w.hues} type={w.type} className="aspect-square rounded-xl" /></Link>
                  <p className="mt-1 text-sm">{w.title}</p>
                  <button aria-label="Remove" onClick={() => patch((m) => ({ ...m, workIds: m.workIds.filter((x) => x !== id) }))} className="absolute right-2 top-2 rounded-full bg-background/80 p-1"><X className="h-4 w-4" /></button>
                </div>); })}
            </div>
            {!board.workIds.length && <p className="mt-6 text-muted-foreground">Empty board — add references below.</p>}
            <h3 className="mt-10 font-semibold">Add references</h3>
            <div className="mt-3 grid grid-cols-3 gap-3 md:grid-cols-6">
              {works.filter((w) => !board.workIds.includes(w.id)).map((w) => (
                <button key={w.id} onClick={() => patch((m) => ({ ...m, workIds: [...m.workIds, w.id] }))} className="text-left text-xs">
                  <Art hues={w.hues} type={w.type} className="aspect-square rounded-lg transition hover:ring-2 hover:ring-primary" /><span className="mt-1 block truncate">{w.title}</span>
                </button>))}
            </div>
          </div>
        ) : <p className="text-muted-foreground">Create a board to start.</p>}
      </div>
    </>
  );
}
