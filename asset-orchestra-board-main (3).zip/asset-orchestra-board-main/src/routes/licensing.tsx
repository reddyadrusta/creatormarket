import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, X } from "lucide-react";
import { LICENSES } from "@/lib/data";
import { PageHeader, btnCls } from "@/components/market";

export const Route = createFileRoute("/licensing")({
  head: () => ({ meta: [
    { title: "Compare licenses — Creator Market" },
    { name: "description", content: "Personal, Standard, Commercial and Exclusive licenses for AI artwork compared side by side." },
    { property: "og:title", content: "Compare licenses — Creator Market" },
    { property: "og:description", content: "Clear commercial-use and attribution terms for every piece." },
  ] }),
  component: Licensing,
});

function Licensing() {
  return (
    <>
      <PageHeader title="Licensing" sub="Every piece declares its license type and commercial-use status. Compare what each tier allows." />
      <div className="mx-auto max-w-7xl px-5 py-10">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {LICENSES.map((l) => (
            <div key={l.id} className={`rounded-2xl border p-6 ${l.id === "commercial" ? "border-primary bg-primary/5" : "border-border bg-card"}`}>
              <h3 className="font-display text-2xl font-bold">{l.name}</h3>
              <p className="mt-1 text-primary">{l.price}</p>
              <ul className="mt-4 space-y-2 text-sm">{l.points.map((p) => <li key={p} className="flex gap-2"><Check className="h-4 w-4 shrink-0 text-primary" />{p}</li>)}</ul>
              <Link to="/explore" search={l.commercial ? { license: "commercial" } : {}} className={`${btnCls} mt-6 w-full`}>Browse {l.name.toLowerCase()} works</Link>
            </div>
          ))}
        </div>
        <div className="mt-10 overflow-x-auto rounded-2xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-card"><tr><th className="p-3 text-left">Feature</th>{LICENSES.map((l) => <th key={l.id} className="p-3">{l.name}</th>)}</tr></thead>
            <tbody>
              {[["Commercial use", (l: typeof LICENSES[number]) => l.commercial], ["Attribution required", (l: typeof LICENSES[number]) => l.attribution], ["Paid advertising", (l: typeof LICENSES[number]) => l.id === "commercial" || l.id === "exclusive"], ["Exclusive rights", (l: typeof LICENSES[number]) => l.id === "exclusive"]].map(([name, f]) => (
                <tr key={name as string} className="border-t border-border"><td className="p-3">{name as string}</td>{LICENSES.map((l) => <td key={l.id} className="p-3 text-center">{(f as (l: typeof LICENSES[number]) => boolean)(l) ? <Check className="mx-auto h-4 w-4 text-primary" /> : <X className="mx-auto h-4 w-4 text-muted-foreground" />}</td>)}</tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
