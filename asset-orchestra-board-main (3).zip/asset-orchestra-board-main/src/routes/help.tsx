import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { PageHeader, btnCls, inputCls } from "@/components/market";

export const Route = createFileRoute("/help")({
  head: () => ({ meta: [
    { title: "Help center — Creator Market" },
    { name: "description", content: "Answers about licensing, payments, verification and briefs." },
    { property: "og:title", content: "Help center — Creator Market" },
    { property: "og:description", content: "Answers about licensing, payments and briefs." },
  ] }),
  component: Help,
});

const FAQ = [
  ["How does licensing work?", "Each work lists a default license. Premium works let you pick Personal, Standard, Commercial or Exclusive at checkout; your license file downloads from the work page."],
  ["What does 'Verified' mean?", "Verified creators passed identity checks and submitted their tools and workflow for review."],
  ["Can I use free artwork commercially?", "Free works are usually Personal license — check the 'Commercial use' field on each piece."],
  ["How do briefs work?", "Post a brief (the AI Brief Builder can draft it for you), creators send proposals, and you pick one from your dashboard."],
  ["What are moodboards?", "Boards that collect references and notes to share direction with creators."],
  ["How do I get paid as a creator?", "Join with a creator account, respond to briefs, and receive payment on accepted proposals."],
];

function Help() {
  const [q, setQ] = useState("");
  const list = FAQ.filter(([a, b]) => (a + b).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <PageHeader title="Help center" sub="Everything about buying, licensing and creating." />
      <div className="mx-auto max-w-3xl px-5 py-10">
        <input className={inputCls} placeholder="Search help…" value={q} onChange={(e) => setQ(e.target.value)} />
        <Accordion type="single" collapsible className="mt-6">{list.map(([a, b]) => <AccordionItem key={a} value={a}><AccordionTrigger>{a}</AccordionTrigger><AccordionContent className="text-muted-foreground">{b}</AccordionContent></AccordionItem>)}</Accordion>
        <h2 className="mt-12 font-display text-2xl font-bold">Still need help?</h2>
        <form className="mt-4 space-y-3" onSubmit={(e) => { e.preventDefault(); (e.target as HTMLFormElement).reset(); toast.success("Thanks — our team will reply within 24h"); }}>
          <input required type="email" className={inputCls} placeholder="Your email" />
          <textarea required className={inputCls} rows={4} placeholder="How can we help?" />
          <button className={btnCls}>Send</button>
        </form>
      </div>
    </>
  );
}
