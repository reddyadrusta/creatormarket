import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Search, ShieldCheck } from "lucide-react";
import { CATEGORIES, collections, creators, works } from "@/lib/data";
import { CreatorCard, Section, WorkCard, btnCls } from "@/components/market";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Creator Market — Curated AI artwork from verified creators" },
      { name: "description", content: "Discover, collect and license generative art, AI film, animation and audio with clear commercial-use terms." },
      { property: "og:title", content: "Creator Market — Curated AI artwork" },
      { property: "og:description", content: "Discover, collect and license generative art from verified AI creators." },
    ],
  }),
  component: Home,
});

const Grid = ({ ids }: { ids: typeof works }) => <div className="grid grid-cols-2 gap-5 md:grid-cols-4">{ids.map((w) => <WorkCard key={w.id} work={w} />)}</div>;

function Home() {
  const nav = useNavigate();
  const [q, setQ] = useState("");
  const trending = [...works].sort((a, b) => b.views - a.views).slice(0, 4);
  const picks = works.filter((w) => w.editorsPick).slice(0, 4);
  const newest = [...works].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 4);
  const free = works.filter((w) => w.price === 0).slice(0, 4);
  const premium = collections[0].workIds.map((id) => works.find((w) => w.id === id)!);
  return (
    <>
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 opacity-60" style={{ background: "radial-gradient(ellipse at 20% 0%, oklch(0.82 0.16 75 / 0.25), transparent 50%), radial-gradient(ellipse at 90% 60%, oklch(0.6 0.2 330 / 0.2), transparent 50%)" }} />
        <div className="relative mx-auto max-w-7xl px-5 py-24">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">AI-native creative marketplace</p>
          <h1 className="mt-4 max-w-4xl font-display text-5xl font-extrabold leading-[1.05] md:text-7xl">Curated AI artwork from verified creators</h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground">Discover, collect and license generative art — with licensing, attribution and commercial-use clarity built into every piece.</p>
          <form onSubmit={(e) => { e.preventDefault(); nav({ to: "/explore", search: { q } }); }} className="mt-8 flex max-w-xl gap-2 rounded-full border border-border bg-card p-1.5">
            <Search className="ml-3 h-5 w-5 self-center text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search works, moods, creators…" className="flex-1 bg-transparent px-2 outline-none" />
            <button className={btnCls}>Search</button>
          </form>
          <div className="mt-6 flex flex-wrap gap-2">{CATEGORIES.slice(0, 5).map((c) => <Link key={c.type} to="/explore" search={{ type: c.type }} className="rounded-full border border-border px-4 py-1.5 text-sm hover:border-primary hover:text-primary">{c.label}</Link>)}</div>
          <p className="mt-6 inline-flex items-center gap-2 text-sm text-muted-foreground"><ShieldCheck className="h-4 w-4 text-primary" />Verified workflows · Licensed for commercial use</p>
        </div>
      </section>
      <Section title="Trending artwork" sub="The most-viewed pieces right now." to="/explore" search={{ sort: "trending" }}><Grid ids={trending} /></Section>
      <Section title="Editor's Picks" sub="Hand-selected standout work from our curation team."><Grid ids={picks} /></Section>
      <Section title="New Arrivals" sub="Fresh from the studio — the latest published pieces." to="/explore" search={{ sort: "newest" }}><Grid ids={newest} /></Section>
      <Section title="Free Artwork" sub="Free to download and use under each piece's license terms." to="/explore" search={{ pricing: "free" }}><Grid ids={free} /></Section>
      <Section title="Premium Collections" sub="Exclusive, licensable showpieces for brands and campaigns." to="/collections"><Grid ids={premium} /></Section>
      <Section title="Featured Creators" sub="Top-rated AI-native talent, vetted for tools and workflows." to="/browse">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">{[...creators].sort((a, b) => b.rating - a.rating).slice(0, 4).map((c) => <CreatorCard key={c.id} c={c} />)}</div>
      </Section>
      <section className="mx-auto max-w-7xl px-5 py-12">
        <h2 className="font-display text-3xl font-bold">How Creator Market works</h2>
        <div className="mt-6 grid gap-5 md:grid-cols-3">
          {[["1. Discover", "Filter works by mood, category and license. Trust verified creator signals."], ["2. Brief", "Turn a rough idea into a structured brief with the AI Brief Builder — style, format, budget, licensing."], ["3. License & deliver", "Agree licensing & attribution, save references to moodboards, and manage delivery from your dashboard."]].map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-border bg-card p-6"><h3 className="font-display text-xl font-semibold text-primary">{t}</h3><p className="mt-2 text-muted-foreground">{d}</p></div>
          ))}
        </div>
        <div className="mt-8 flex gap-3"><Link to="/explore" className={btnCls}>Start exploring</Link><Link to="/briefs/new" className="inline-flex items-center rounded-full border border-border px-5 py-2 text-sm hover:bg-secondary">Build a brief with AI</Link></div>
      </section>
    </>
  );
}
