import { createFileRoute, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { BadgeCheck, MapPin, Star } from "lucide-react";
import { getCreator, worksBy } from "@/lib/data";
import { useStore, uid, today } from "@/lib/store";
import { WorkCard, btnCls, btnGhost, inputCls } from "@/components/market";

export const Route = createFileRoute("/creator/$id")({
  loader: ({ params }) => { const c = getCreator(params.id); if (!c) throw notFound(); return { c }; },
  head: ({ loaderData }) => ({ meta: [
    { title: loaderData ? `${loaderData.c.name} — ${loaderData.c.title} | Creator Market` : "Creator | Creator Market" },
    { name: "description", content: loaderData?.c.bio ?? "AI creator profile" },
    { property: "og:title", content: loaderData ? `${loaderData.c.name} on Creator Market` : "Creator" },
    { property: "og:description", content: loaderData?.c.bio ?? "AI creator profile" },
  ] }),
  component: CreatorPage,
});

function CreatorPage() {
  const { c } = Route.useLoaderData();
  const { following, user, update } = useStore();
  const [msg, setMsg] = useState(""); const [open, setOpen] = useState(false);
  const isF = following.includes(c.id);
  const list = worksBy(c.id);
  return (
    <div className="mx-auto max-w-7xl px-5 py-12">
      <div className="flex flex-col gap-6 md:flex-row md:items-center">
        <div className="h-28 w-28 rounded-full" style={{ background: `conic-gradient(oklch(0.7 0.18 ${c.hue}), oklch(0.5 0.2 ${c.hue + 60}), oklch(0.7 0.18 ${c.hue}))` }} />
        <div className="flex-1">
          {c.verified && <span className="inline-flex items-center gap-1 text-sm text-primary"><BadgeCheck className="h-4 w-4" />Verified creator</span>}
          <h1 className="font-display text-4xl font-bold">{c.name}</h1>
          <p className="text-muted-foreground">{c.title}</p>
          <div className="mt-2 flex flex-wrap gap-4 text-sm"><span className="inline-flex items-center gap-1"><Star className="h-4 w-4 fill-primary text-primary" />{c.rating.toFixed(1)}</span><span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4" />{c.location}</span><span>{(c.followers + (isF ? 1 : 0)).toLocaleString()} followers</span><span>From ${c.rate}/hr</span></div>
        </div>
        <div className="flex gap-2">
          <button className={isF ? btnGhost : btnCls} onClick={() => { update((s) => ({ ...s, following: isF ? s.following.filter((x) => x !== c.id) : [...s.following, c.id] })); toast(isF ? "Unfollowed" : `Following ${c.name}`); }}>{isF ? "Following" : "Follow"}</button>
          <button className={btnGhost} onClick={() => setOpen(!open)}>Contact / Hire</button>
        </div>
      </div>
      {open && (
        <form className="mt-6 max-w-xl space-y-3 rounded-2xl border border-border bg-card p-5" onSubmit={(e) => { e.preventDefault(); if (!user) return toast.error("Please log in to message creators"); if (!msg.trim()) return; update((s) => ({ ...s, messages: [...s.messages, { id: uid(), creatorId: c.id, text: msg, date: today() }] })); setMsg(""); setOpen(false); toast.success(`Message sent to ${c.name}`); }}>
          <textarea className={inputCls} rows={4} placeholder={`Tell ${c.name} about your project…`} value={msg} onChange={(e) => setMsg(e.target.value)} />
          <button className={btnCls}>Send message</button>
        </form>
      )}
      <p className="mt-8 max-w-3xl text-lg">{c.bio}</p>
      <div className="mt-4 flex flex-wrap gap-2">{c.tools.map((t) => <span key={t} className="rounded-full bg-secondary px-3 py-1 text-sm">{t}</span>)}{c.specialties.map((t) => <span key={t} className="rounded-full border border-primary px-3 py-1 text-sm text-primary">{t}</span>)}</div>
      <h2 className="mt-12 font-display text-2xl font-bold">Portfolio ({list.length})</h2>
      <div className="mt-5 grid grid-cols-2 gap-5 md:grid-cols-4">{list.map((w) => <WorkCard key={w.id} work={w} />)}</div>
    </div>
  );
}
