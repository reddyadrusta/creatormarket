import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";
import { LICENSES, TYPE_LABEL, type LicenseType, type WorkType } from "@/lib/data";
import { useStore, uid, today } from "@/lib/store";
import { buildBrief } from "@/lib/brief.functions";
import { PageHeader, RequireAuth, btnCls, inputCls } from "@/components/market";

export const Route = createFileRoute("/briefs/new")({
  head: () => ({ meta: [
    { title: "AI Brief Builder — Creator Market" },
    { name: "description", content: "Turn a rough idea into a structured creative brief with AI." },
    { property: "og:title", content: "AI Brief Builder — Creator Market" },
    { property: "og:description", content: "Structured briefs from rough ideas in seconds." },
  ] }),
  component: () => <RequireAuth><NewBrief /></RequireAuth>,
});

function NewBrief() {
  const gen = useServerFn(buildBrief);
  const { user, update } = useStore();
  const nav = useNavigate();
  const [idea, setIdea] = useState(""); const [loading, setLoading] = useState(false);
  const [f, setF] = useState({ title: "", type: "video" as WorkType, style: "", budget: 500, license: "standard" as LicenseType, deadline: "", description: "" });
  const run = async () => {
    if (idea.trim().length < 3) return toast.error("Describe your idea first");
    setLoading(true);
    try {
      const b = await gen({ data: { idea } });
      setF((x) => ({ ...x, title: b.title, type: b.type, style: b.style, budget: Math.round(b.budget), license: b.license, description: `${b.description}\n\nDeliverables:\n${b.deliverables.map((d) => `• ${d}`).join("\n")}` }));
      toast.success("Brief drafted — review and post");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); } finally { setLoading(false); }
  };
  return (
    <>
      <PageHeader title="AI Brief Builder" sub="Describe your idea in plain words — we'll structure style, format, budget and licensing." />
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-10 lg:grid-cols-2">
        <div className="space-y-3">
          <textarea className={inputCls} rows={8} placeholder="e.g. A dreamy 20-second vertical ad for our new perfume, pastel tones, for Instagram and TikTok paid ads…" value={idea} onChange={(e) => setIdea(e.target.value)} />
          <button className={btnCls} onClick={run} disabled={loading}><Sparkles className="h-4 w-4" />{loading ? "Drafting…" : "Generate brief"}</button>
        </div>
        <form className="space-y-3 rounded-2xl border border-border bg-card p-5" onSubmit={(e) => { e.preventDefault(); update((s) => ({ ...s, briefs: [{ id: uid(), ...f, owner: user!.name, proposals: 0, createdAt: today(), mine: true }, ...s.briefs] })); toast.success("Brief posted"); nav({ to: "/briefs" }); }}>
          <input required className={inputCls} placeholder="Title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <select className={inputCls} value={f.type} onChange={(e) => setF({ ...f, type: e.target.value as WorkType })}>{Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
            <select className={inputCls} value={f.license} onChange={(e) => setF({ ...f, license: e.target.value as LicenseType })}>{LICENSES.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
            <input required type="number" min={1} className={inputCls} placeholder="Budget $" value={f.budget} onChange={(e) => setF({ ...f, budget: Number(e.target.value) })} />
            <input required type="date" className={inputCls} value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} />
          </div>
          <input className={inputCls} placeholder="Style / moods" value={f.style} onChange={(e) => setF({ ...f, style: e.target.value })} />
          <textarea required className={inputCls} rows={7} placeholder="Description" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <button className={btnCls}>Post brief</button>
        </form>
      </div>
    </>
  );
}
