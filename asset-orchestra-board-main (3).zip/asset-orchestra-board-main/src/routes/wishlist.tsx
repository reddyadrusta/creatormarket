import { createFileRoute, Link } from "@tanstack/react-router";
import { getWork } from "@/lib/data";
import { useStore } from "@/lib/store";
import { PageHeader, WorkCard, btnCls, btnGhost } from "@/components/market";

export const Route = createFileRoute("/wishlist")({
  head: () => ({ meta: [
    { title: "Your wishlist — Creator Market" },
    { name: "description", content: "AI artwork you've saved for later." },
    { property: "og:title", content: "Wishlist — Creator Market" },
    { property: "og:description", content: "Saved AI artwork." },
  ] }),
  component: Wishlist,
});

function Wishlist() {
  const { wishlist, update } = useStore();
  const items = wishlist.map(getWork).filter(Boolean);
  return (
    <>
      <PageHeader title="Wishlist" sub="Pieces you've saved. Tap the heart on any work to add it." />
      <div className="mx-auto max-w-7xl px-5 py-10">
        {items.length ? (<>
          <div className="mb-5 flex justify-between"><p className="text-sm text-muted-foreground">{items.length} saved</p><button className={btnGhost} onClick={() => update((s) => ({ ...s, wishlist: [] }))}>Clear wishlist</button></div>
          <div className="grid grid-cols-2 gap-5 md:grid-cols-4">{items.map((w) => <WorkCard key={w!.id} work={w!} />)}</div>
        </>) : (
          <div className="py-20 text-center"><p className="text-muted-foreground">Your wishlist is empty.</p><Link to="/explore" className={`${btnCls} mt-4`}>Explore works</Link></div>
        )}
      </div>
    </>
  );
}
