import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { TYPE_LABEL } from "@/lib/data";
import { useStore, uid, today } from "@/lib/store";
import { PageHeader, btnCls, btnGhost, inputCls } from "@/components/market";

export const Route = createFileRoute("/briefs/")({
  head: () => ({ meta: [
    { title: "Open briefs — Creator Market" },
    { name: "description", content: "Brands and agencies posting AI creative briefs. Send a proposal." },
    { property: "og:title", content: "Open briefs — Creator Market" },
    { property: "og:description", content: "Live AI creative briefs from brands." },
  ] }),
  component: Briefs,
});

function Briefs() {
  const { briefs, user, proposals, update } = useStore();
  const [type, setType] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [msg, setMsg] = useState(""); const [price, setPrice] = useState("");
  const list = briefs.filter((b) => !type || b.type === type);
  return (
    <>
      <PageHeader title="Open briefs" sub="Live projects from brands and agencies.">
        <Link to="/briefs/new" className={`${btnCls} mt-6`}>Post a brief with AI</Link>
      </PageHeader>
      <div className="mx-auto max-w-5xl px-5 py-10">
        <select className={`${inputCls} mb-6 w-auto`} value={type} onChange={(e) => setType(e.target.value)}><option value="">All formats</option>{Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <div className="space-y-4">
          {list.map((b) => { const sent = proposals.some((p) => p.briefId === b.id); return (
            <div key={b.id} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h3 className="font-display text-xl font-semibold">{b.title}</h3><p className="text-sm text-muted-foreground">{b.owner} · {TYPE_LABEL[b.type]} · due {b.deadline}</p></div>
                <div className="text-right"><div className="text-xl font-bold text-primary">${b.budget.toLocaleString()}</div><div className="text-xs capitalize text-muted-foreground">{b.license} license · {b.proposals} proposals</div></div>
              </div>
              <p className="mt-3 text-sm">{b.description}</p>
              <p className="mt-2 text-xs text-muted-foreground">Style: {b.style}</p>
              <div className="mt-4 flex gap-2">
                {b.mine ? <button className={btnGhost} onClick={() => update((s) => ({ ...s, briefs: s.briefs.filter((x) => x.id !== b.id) }))}>Close brief</button>
                  : sent ? <span className="text-sm text-primary">Proposal sent ✓</span>
                  : <button className={btnCls} onClick={() => setOpen(open === b.id ? null : b.id)}>Send proposal</button>}
              </div>
              {open === b.id && (
                <form className="mt-4 space-y-2" onSubmit={(e) => { e.preventDefault(); if (!user) return toast.error("Log in to send proposals"); update((s) => ({ ...s, proposals: [...s.proposals, { id: uid(), briefId: b.id, message: msg, price: Number(price), date: today() }], briefs: s.briefs.map((x) => x.id === b.id ? { ...x, proposals: x.proposals + 1 } : x) })); setOpen(null); setMsg(""); setPrice(""); toast.success("Proposal sent"); }}>
                  <textarea required className={inputCls} rows={3} placeholder="Your approach, tools and timeline…" value={msg} onChange={(e) => setMsg(e.target.value)} />
                  <div className="flex gap-2"><input required type="number" min={1} className={inputCls} placeholder="Your quote ($)" value={price} onChange={(e) => setPrice(e.target.value)} /><button className={btnCls}>Submit</button></div>
                </form>
              )}
            </div>); })}
          {!list.length && <p className="py-10 text-center text-muted-foreground">No briefs in this format yet.</p>}
        </div>
      </div>
    </>
  );
}
