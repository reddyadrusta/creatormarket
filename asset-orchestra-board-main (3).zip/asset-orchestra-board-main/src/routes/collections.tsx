import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { collections, getWork } from "@/lib/data";
import { Art, PageHeader, WorkCard } from "@/components/market";

export const Route = createFileRoute("/collections")({
  head: () => ({ meta: [
    { title: "Curated collections — Creator Market" },
    { name: "description", content: "Curated sets of licensable AI artwork for brands, campaigns and starters." },
    { property: "og:title", content: "Curated collections — Creator Market" },
    { property: "og:description", content: "Licensable showpieces grouped for campaigns." },
  ] }),
  component: Collections,
});

function Collections() {
  const [open, setOpen] = useState(collections[0].id);
  return (
    <>
      <PageHeader title="Collections" sub="Exclusive, licensable showpieces for brands and campaigns." />
      <div className="mx-auto max-w-7xl space-y-6 px-5 py-10">
        {collections.map((c) => {
          const items = c.workIds.map((id) => getWork(id)!);
          return (
            <div key={c.id} className="rounded-2xl border border-border bg-card p-5">
              <button className="flex w-full items-center gap-4 text-left" onClick={() => setOpen(open === c.id ? "" : c.id)}>
                <div className="flex -space-x-4">{items.slice(0, 3).map((w) => <Art key={w.id} hues={w.hues} className="h-14 w-14 rounded-lg border-2 border-card" />)}</div>
                <div className="flex-1"><h3 className="font-display text-xl font-semibold">{c.name}</h3><p className="text-sm text-muted-foreground">{c.description} · {items.length} works</p></div>
                <span className="text-primary">{open === c.id ? "Hide" : "View"}</span>
              </button>
              {open === c.id && <div className="mt-6 grid grid-cols-2 gap-5 md:grid-cols-4">{items.map((w) => <WorkCard key={w.id} work={w} />)}</div>}
            </div>
          );
        })}
      </div>
    </>
  );
}
