import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Check, Download, Eye, X } from "lucide-react";
import { LICENSES, TYPE_LABEL, getCreator, getWork, works, type LicenseType } from "@/lib/data";
import { useStore, uid, today } from "@/lib/store";
import { Art, WishButton, WorkCard, btnCls, btnGhost, inputCls } from "@/components/market";

export const Route = createFileRoute("/work/$id")({
  loader: ({ params }) => { const w = getWork(params.id); if (!w) throw notFound(); return { w }; },
  head: ({ loaderData }) => ({ meta: [
    { title: loaderData ? `${loaderData.w.title} — Creator Market` : "Artwork | Creator Market" },
    { name: "description", content: loaderData?.w.description ?? "AI artwork" },
    { property: "og:title", content: loaderData?.w.title ?? "Artwork" },
    { property: "og:description", content: loaderData?.w.description ?? "AI artwork" },
  ] }),
  component: WorkPage,
});

const MULT: Record<LicenseType, number> = { personal: 0.5, standard: 1, commercial: 1.8, exclusive: 5 };

function WorkPage() {
  const { w } = Route.useLoaderData();
  const c = getCreator(w.creatorId)!;
  const { user, purchases, moodboards, update } = useStore();
  const [lic, setLic] = useState<LicenseType>(w.license);
  const [checkout, setCheckout] = useState(false);
  const [board, setBoard] = useState(moodboards[0]?.id ?? "");
  const owned = purchases.find((p) => p.workId === w.id);
  const price = w.price === 0 ? 0 : Math.round(w.price * MULT[lic]);
  const related = works.filter((x) => x.id !== w.id && (x.type === w.type || x.tags.some((t) => w.tags.includes(t)))).slice(0, 4);

  const acquire = () => {
    if (!user) return toast.error("Please log in first");
    update((s) => ({ ...s, purchases: [...s.purchases, { id: uid(), workId: w.id, license: lic, price, date: today() }] }));
    setCheckout(false);
    toast.success(price ? `Licensed for $${price}` : "Added to your library");
  };
  const download = () => {
    const blob = new Blob([`${w.title}\nCreator: ${c.name}\nLicense: ${owned?.license}\nTools: ${w.tools.join(", ")}\nWorkflow: ${w.workflow}\nAttribution: "${w.title}" by ${c.name} via Creator Market`], { type: "text/plain" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${w.id}-license.txt`; a.click();
  };

  return (
    <div className="mx-auto max-w-7xl px-5 py-12">
      <div className="grid gap-10 lg:grid-cols-[1.3fr_1fr]">
        <Art hues={w.hues} type={w.type} className="aspect-[4/3] rounded-2xl" />
        <div>
          <p className="text-sm text-muted-foreground">{TYPE_LABEL[w.type]} · <span className="inline-flex items-center gap-1"><Eye className="h-3.5 w-3.5" />{w.views.toLocaleString()} views</span></p>
          <h1 className="mt-1 font-display text-4xl font-bold">{w.title}</h1>
          <Link to="/creator/$id" params={{ id: c.id }} className="mt-2 inline-block text-primary hover:underline">by {c.name}</Link>
          <p className="mt-4 text-muted-foreground">{w.description}</p>
          <div className="mt-4 flex flex-wrap gap-1.5">{w.tags.map((t) => <Link key={t} to="/explore" search={{ mood: t }} className="rounded-full border border-border px-2.5 py-0.5 text-xs hover:border-primary">{t}</Link>)}</div>
          <dl className="mt-6 grid grid-cols-2 gap-3 rounded-xl border border-border bg-card p-4 text-sm">
            <dt className="text-muted-foreground">Tools</dt><dd>{w.tools.join(", ")}</dd>
            <dt className="text-muted-foreground">Workflow</dt><dd>{w.workflow}</dd>
            <dt className="text-muted-foreground">Default license</dt><dd className="capitalize">{w.license}</dd>
            <dt className="text-muted-foreground">Commercial use</dt><dd>{w.commercial ? <Check className="h-4 w-4 text-primary" /> : <X className="h-4 w-4 text-destructive" />}</dd>
          </dl>
          {w.price > 0 && !owned && (
            <div className="mt-6"><h4 className="mb-2 text-sm font-semibold">Choose license</h4><div className="grid grid-cols-2 gap-2">
              {LICENSES.map((l) => <button key={l.id} onClick={() => setLic(l.id)} className={`rounded-lg border p-3 text-left text-sm ${lic === l.id ? "border-primary bg-primary/10" : "border-border"}`}><div className="font-semibold">{l.name}</div><div className="text-muted-foreground">${Math.round(w.price * MULT[l.id])}</div></button>)}
            </div></div>
          )}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            {owned ? <button className={btnCls} onClick={download}><Download className="h-4 w-4" />Download license & files</button>
              : <button className={btnCls} onClick={() => (price ? setCheckout(true) : acquire())}>{price ? `License for $${price}` : "Get for free"}</button>}
            <WishButton id={w.id} />
          </div>
          {owned && <p className="mt-2 text-sm text-primary">You own a {owned.license} license (since {owned.date}).</p>}
          <div className="mt-6 flex gap-2">
            <select className={inputCls} value={board} onChange={(e) => setBoard(e.target.value)}>{moodboards.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
            <button className={btnGhost} onClick={() => { update((s) => ({ ...s, moodboards: s.moodboards.map((m) => m.id === board && !m.workIds.includes(w.id) ? { ...m, workIds: [...m.workIds, w.id] } : m) })); toast.success("Saved to moodboard"); }}>Save to moodboard</button>
          </div>
        </div>
      </div>
      {checkout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4" onClick={() => setCheckout(false)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={(e) => { e.preventDefault(); acquire(); }} className="w-full max-w-md space-y-3 rounded-2xl border border-border bg-card p-6">
            <h3 className="font-display text-2xl font-bold">Checkout</h3>
            <p className="text-sm text-muted-foreground">{w.title} · <span className="capitalize">{lic}</span> license</p>
            <input required className={inputCls} placeholder="Name on card" />
            <input required className={inputCls} placeholder="Card number" inputMode="numeric" pattern="[0-9 ]{12,19}" />
            <div className="flex gap-2"><input required className={inputCls} placeholder="MM/YY" /><input required className={inputCls} placeholder="CVC" /></div>
            <div className="flex items-center justify-between pt-2"><span className="text-xl font-bold">${price}</span><button className={btnCls}>Pay & license</button></div>
            <p className="text-xs text-muted-foreground">Demo checkout — no real charge is made.</p>
          </form>
        </div>
      )}
      <h2 className="mt-16 font-display text-2xl font-bold">Related works</h2>
      <div className="mt-5 grid grid-cols-2 gap-5 md:grid-cols-4">{related.map((x) => <WorkCard key={x.id} work={x} />)}</div>
    </div>
  );
}
