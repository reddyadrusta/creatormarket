import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useStore } from "@/lib/store";
import { btnCls, inputCls } from "@/components/market";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [
    { title: "Join Creator Market" },
    { name: "description", content: "Create a buyer or creator account on the AI-native creative marketplace." },
    { property: "og:title", content: "Join Creator Market" },
    { property: "og:description", content: "Sign up as a buyer or AI creator." },
  ] }),
  component: Register,
});

function Register() {
  const { accounts, update } = useStore();
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "", role: "buyer" as "buyer" | "creator" });
  return (
    <div className="mx-auto max-w-sm px-5 py-20">
      <h1 className="font-display text-3xl font-bold">Join Creator Market</h1>
      <form className="mt-6 space-y-3" onSubmit={(e) => {
        e.preventDefault();
        if (f.password.length < 6) return toast.error("Password must be at least 6 characters");
        if (accounts.some((a) => a.email.toLowerCase() === f.email.toLowerCase())) return toast.error("Email already registered");
        update((s) => ({ ...s, accounts: [...s.accounts, f], user: { name: f.name, email: f.email, role: f.role } }));
        toast.success("Account created"); nav({ to: "/dashboard" });
      }}>
        <div className="grid grid-cols-2 gap-2">{(["buyer", "creator"] as const).map((r) => <button type="button" key={r} onClick={() => setF({ ...f, role: r })} className={`rounded-lg border p-3 text-sm capitalize ${f.role === r ? "border-primary bg-primary/10" : "border-border"}`}>I'm a {r}</button>)}</div>
        <input required className={inputCls} placeholder="Full name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input required type="email" className={inputCls} placeholder="Email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <input required type="password" className={inputCls} placeholder="Password (6+ chars)" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        <button className={`${btnCls} w-full`}>Create account</button>
      </form>
      <p className="mt-4 text-sm text-muted-foreground">Have an account? <Link to="/login" className="text-primary">Log in</Link></p>
    </div>
  );
}
