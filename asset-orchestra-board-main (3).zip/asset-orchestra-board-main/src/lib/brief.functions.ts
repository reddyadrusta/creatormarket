import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Out = z.object({
  title: z.string(), type: z.enum(["video", "image", "animation", "3d", "music", "motion"]),
  style: z.string(), budget: z.number(), license: z.enum(["personal", "standard", "commercial", "exclusive"]),
  description: z.string(), deliverables: z.array(z.string()),
});

export const buildBrief = createServerFn({ method: "POST" })
  .inputValidator((i: { idea: string }) => z.object({ idea: z.string().min(3).max(2000) }).parse(i))
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI is not configured");
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "You turn rough creative ideas into structured briefs for an AI creative marketplace. Budget in USD." },
          { role: "user", content: data.idea },
        ],
        tools: [{ type: "function", function: { name: "brief", description: "Structured brief", parameters: {
          type: "object", required: ["title", "type", "style", "budget", "license", "description", "deliverables"],
          properties: {
            title: { type: "string" }, type: { type: "string", enum: ["video", "image", "animation", "3d", "music", "motion"] },
            style: { type: "string", description: "Comma separated moods" }, budget: { type: "number" },
            license: { type: "string", enum: ["personal", "standard", "commercial", "exclusive"] },
            description: { type: "string" }, deliverables: { type: "array", items: { type: "string" } },
          } } } }],
        tool_choice: { type: "function", function: { name: "brief" } },
      }),
    });
    if (res.status === 429) throw new Error("Too many requests — try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted.");
    if (!res.ok) throw new Error("AI request failed");
    const j = await res.json();
    const args = j.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    return Out.parse(JSON.parse(args));
  });
