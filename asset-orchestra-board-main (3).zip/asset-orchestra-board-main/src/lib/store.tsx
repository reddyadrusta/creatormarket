import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { openBriefsSeed, type LicenseType, type WorkType } from "./data";

export interface User { name: string; email: string; role: "buyer" | "creator" }
export interface Moodboard { id: string; name: string; workIds: string[]; notes: string }
export interface Brief { id: string; title: string; type: WorkType; budget: number; style: string; license: LicenseType; deadline: string; description: string; owner: string; proposals: number; createdAt: string; mine?: boolean }
export interface Purchase { id: string; workId: string; license: LicenseType; price: number; date: string }
export interface Proposal { id: string; briefId: string; message: string; price: number; date: string }

interface State {
  user: User | null;
  accounts: (User & { password: string })[];
  wishlist: string[];
  moodboards: Moodboard[];
  briefs: Brief[];
  purchases: Purchase[];
  following: string[];
  proposals: Proposal[];
  messages: { id: string; creatorId: string; text: string; date: string }[];
}

const initial: State = {
  user: null, accounts: [], wishlist: [], moodboards: [{ id: "mb-1", name: "Launch campaign", workIds: [], notes: "" }],
  briefs: openBriefsSeed, purchases: [], following: [], proposals: [], messages: [],
};

const KEY = "creator-market-state-v1";
type Ctx = State & { update: (fn: (s: State) => State) => void; hydrated: boolean };
const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(initial);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) setState({ ...initial, ...JSON.parse(raw) }); } catch {}
    setHydrated(true);
  }, []);
  useEffect(() => { if (hydrated) localStorage.setItem(KEY, JSON.stringify(state)); }, [state, hydrated]);
  return <StoreCtx.Provider value={{ ...state, hydrated, update: (fn) => setState((s) => fn(s)) }}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("StoreProvider missing");
  return c;
}

export const uid = () => Math.random().toString(36).slice(2, 10);
export const today = () => new Date().toISOString().slice(0, 10);
