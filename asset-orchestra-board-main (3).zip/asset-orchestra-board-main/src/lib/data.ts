export type WorkType = "video" | "image" | "animation" | "3d" | "music" | "motion";
export type LicenseType = "personal" | "standard" | "commercial" | "exclusive";

export interface Creator {
  id: string;
  name: string;
  title: string;
  rating: number;
  location: string;
  bio: string;
  tools: string[];
  specialties: string[];
  verified: boolean;
  rate: number;
  hue: number;
  followers: number;
}

export interface Work {
  id: string;
  title: string;
  type: WorkType;
  creatorId: string;
  price: number; // 0 = free
  tags: string[];
  views: number;
  createdAt: string;
  license: LicenseType;
  commercial: boolean;
  tools: string[];
  workflow: string;
  description: string;
  editorsPick?: boolean;
  hues: [number, number];
}

export const TYPE_LABEL: Record<WorkType, string> = {
  video: "Video",
  image: "Image",
  animation: "Animation",
  "3d": "3D",
  music: "Music",
  motion: "Motion",
};

export const CATEGORIES: { type: WorkType; label: string; blurb: string }[] = [
  { type: "video", label: "AI Film", blurb: "Cinematic generative video, shorts and trailers." },
  { type: "animation", label: "Animation", blurb: "Character loops, explainers and stylised motion." },
  { type: "image", label: "Generative Art", blurb: "Editorial stills, portraits and product shots." },
  { type: "3d", label: "3D & Motion", blurb: "Rendered objects, scenes and spatial assets." },
  { type: "music", label: "AI Audio", blurb: "Scores, sound design and voice work." },
  { type: "motion", label: "Motion Design", blurb: "Broadcast IDs, logo stings and titles." },
];

export const MOODS = [
  "Cinematic", "Cyberpunk", "Noir", "Minimal", "Futuristic", "Nature", "Surreal",
  "Retro", "Vaporwave", "Fantasy", "Dreamcore", "Pop Art",
];

export const LICENSES: { id: LicenseType; name: string; price: string; commercial: boolean; attribution: boolean; points: string[] }[] = [
  { id: "personal", name: "Personal", price: "Free – $29", commercial: false, attribution: true, points: ["Non-commercial projects", "Social posts without paid promotion", "Attribution required", "No resale"] },
  { id: "standard", name: "Standard", price: "$30 – $199", commercial: true, attribution: true, points: ["Commercial use up to 100k impressions", "Websites, decks, organic social", "Attribution required", "No resale as standalone asset"] },
  { id: "commercial", name: "Commercial", price: "$200 – $999", commercial: true, attribution: false, points: ["Unlimited impressions", "Paid ads, broadcast and print", "No attribution needed", "Up to 5 seats"] },
  { id: "exclusive", name: "Exclusive", price: "On request", commercial: true, attribution: false, points: ["Full exclusive rights", "Removed from marketplace", "Custom contract & indemnity", "Unlimited seats"] },
];

export const creators: Creator[] = [
  { id: "priya-sharma", name: "Priya Sharma", title: "Generative Artist & Illustrator", rating: 5.0, location: "Mumbai, IN", bio: "Visual artist producing striking generative imagery for editorial and brand campaigns. Obsessed with texture and light.", tools: ["Midjourney", "DALL·E 3", "Stable Diffusion"], specialties: ["Image"], verified: true, rate: 120, hue: 25, followers: 12400 },
  { id: "aria-nakamura", name: "Aria Nakamura", title: "AI Filmmaker & Director", rating: 4.9, location: "Tokyo, JP", bio: "Award-winning AI filmmaker crafting surreal, cinematic narratives with generative video. Specializes in character consistency across shots and dreamlike color grading.", tools: ["Sora", "Runway Gen-3", "Midjourney"], specialties: ["Video", "Animation"], verified: true, rate: 220, hue: 330, followers: 28100 },
  { id: "sofia-rossi", name: "Sofia Rossi", title: "AI Music & Sound Designer", rating: 4.9, location: "Milan, IT", bio: "Composes AI-generated scores and sound design for films, ads and immersive installs. Cleared for commercial use.", tools: ["Suno", "Udio", "ElevenLabs"], specialties: ["Music"], verified: true, rate: 150, hue: 160, followers: 8300 },
  { id: "daniel-kim", name: "Daniel Kim", title: "Prompt Engineer & AI Director", rating: 4.8, location: "Seoul, KR", bio: "Technical prompt engineer specializing in consistent characters and brand-locked style transfer across long-form generative video.", tools: ["Midjourney", "Runway Gen-3", "Stable Diffusion"], specialties: ["Video", "Image"], verified: true, rate: 180, hue: 210, followers: 15600 },
  { id: "leo-martin", name: "Leo Martin", title: "Motion & Animation Artist", rating: 4.7, location: "Paris, FR", bio: "Fluid brand loops and kinetic type built with generative pipelines and hand-finished in post.", tools: ["Kaiber", "After Effects", "Runway Gen-3"], specialties: ["Animation", "Motion"], verified: true, rate: 110, hue: 270, followers: 6100 },
  { id: "marcus-cole", name: "Marcus Cole", title: "Broadcast Motion Designer", rating: 4.6, location: "London, UK", bio: "Broadcast identities, idents and title sequences for networks and streamers.", tools: ["Cinema 4D", "Runway Gen-3", "Luma"], specialties: ["Motion", "3D"], verified: false, rate: 140, hue: 50, followers: 4200 },
  { id: "noah-bennett", name: "Noah Bennett", title: "Character Animator", rating: 4.6, location: "Austin, US", bio: "Talking characters and avatar-led ads with lip-sync and expressive performance.", tools: ["HeyGen", "Pika", "ElevenLabs"], specialties: ["Animation"], verified: false, rate: 90, hue: 120, followers: 3900 },
  { id: "elena-vasquez", name: "Elena Vasquez", title: "Fashion Film Director", rating: 4.8, location: "Madrid, ES", bio: "AI fashion films and lookbooks with editorial sensibility and couture-level styling.", tools: ["Sora", "Midjourney", "Magnific"], specialties: ["Video", "Image"], verified: true, rate: 200, hue: 0, followers: 11200 },
  { id: "kai-okafor", name: "Kai Okafor", title: "3D Generative Sculptor", rating: 4.7, location: "Lagos, NG", bio: "Generative 3D objects and scenes for product launches and spatial experiences.", tools: ["Luma", "Meshy", "Blender"], specialties: ["3D"], verified: true, rate: 160, hue: 190, followers: 5400 },
];

const w = (o: Omit<Work, "workflow" | "description" | "tools"> & Partial<Work>): Work => {
  const c = creators.find((x) => x.id === o.creatorId)!;
  return {
    tools: c.tools.slice(0, 2),
    workflow: "Prompt design → base generation → upscale & consistency pass → hand-finished grade.",
    description: `${o.title} by ${c.name}. ${o.tags.join(", ")} mood, delivered at production resolution with full source prompts.`,
    ...o,
  };
};

export const works: Work[] = [
  w({ id: "neon-tokyo-dreams", title: "Neon Tokyo Dreams", type: "video", creatorId: "aria-nakamura", price: 450, tags: ["Cinematic", "Cyberpunk", "Noir"], views: 48200, createdAt: "2026-08-02", license: "commercial", commercial: true, editorsPick: true, hues: [320, 200] }),
  w({ id: "liquid-gold-portrait", title: "Liquid Gold Portrait", type: "image", creatorId: "aria-nakamura", price: 0, tags: ["Minimal", "Futuristic"], views: 39100, createdAt: "2026-07-20", license: "personal", commercial: false, editorsPick: true, hues: [45, 20] }),
  w({ id: "fluid-brand-loop", title: "Fluid Brand Loop", type: "animation", creatorId: "leo-martin", price: 95, tags: ["Minimal", "Futuristic"], views: 31800, createdAt: "2026-07-11", license: "standard", commercial: true, hues: [260, 300] }),
  w({ id: "desert-bloom-editorial", title: "Desert Bloom Editorial", type: "image", creatorId: "priya-sharma", price: 120, tags: ["Nature", "Surreal"], views: 29400, createdAt: "2026-06-30", license: "standard", commercial: true, editorsPick: true, hues: [25, 340] }),
  w({ id: "character-lock-series", title: "Character Lock Series", type: "video", creatorId: "daniel-kim", price: 380, tags: ["Cinematic", "Retro"], views: 22100, createdAt: "2026-08-18", license: "commercial", commercial: true, editorsPick: true, hues: [210, 30] }),
  w({ id: "broadcast-motion-id", title: "Broadcast Motion ID", type: "motion", creatorId: "marcus-cole", price: 285, tags: ["Vaporwave", "Fantasy"], views: 9100, createdAt: "2026-10-08", license: "commercial", commercial: true, hues: [290, 180] }),
  w({ id: "talking-character-ad", title: "Talking Character Ad", type: "animation", creatorId: "noah-bennett", price: 0, tags: ["Nature", "Surreal"], views: 7400, createdAt: "2026-10-06", license: "personal", commercial: false, hues: [120, 60] }),
  w({ id: "ai-fashion-lookbook", title: "AI Fashion Lookbook", type: "video", creatorId: "elena-vasquez", price: 0, tags: ["Retro", "Dreamcore"], views: 12800, createdAt: "2026-10-03", license: "personal", commercial: false, hues: [350, 280] }),
  w({ id: "style-transfer-pack", title: "Style Transfer Pack", type: "image", creatorId: "daniel-kim", price: 180, tags: ["Retro", "Pop Art"], views: 8800, createdAt: "2026-09-29", license: "standard", commercial: true, hues: [10, 60] }),
  w({ id: "cinematic-score-ascend", title: "Cinematic Score — Ascend", type: "music", creatorId: "sofia-rossi", price: 0, tags: ["Cinematic", "Fantasy"], views: 15300, createdAt: "2026-09-12", license: "personal", commercial: false, hues: [170, 220] }),
  w({ id: "cosmic-product-shot", title: "Cosmic Product Shot", type: "image", creatorId: "priya-sharma", price: 220, tags: ["Futuristic", "Surreal"], views: 18700, createdAt: "2026-09-02", license: "commercial", commercial: true, hues: [240, 300] }),
  w({ id: "chrome-relic", title: "Chrome Relic", type: "3d", creatorId: "kai-okafor", price: 160, tags: ["Futuristic", "Minimal"], views: 6400, createdAt: "2026-09-20", license: "standard", commercial: true, hues: [190, 230] }),
  w({ id: "floating-isles", title: "Floating Isles", type: "3d", creatorId: "kai-okafor", price: 0, tags: ["Fantasy", "Nature"], views: 5200, createdAt: "2026-08-25", license: "personal", commercial: false, hues: [140, 200] }),
  w({ id: "midnight-ambient", title: "Midnight Ambient Pack", type: "music", creatorId: "sofia-rossi", price: 75, tags: ["Noir", "Dreamcore"], views: 4100, createdAt: "2026-10-01", license: "standard", commercial: true, hues: [230, 260] }),
  w({ id: "couture-in-motion", title: "Couture in Motion", type: "video", creatorId: "elena-vasquez", price: 340, tags: ["Cinematic", "Minimal"], views: 14600, createdAt: "2026-08-10", license: "commercial", commercial: true, hues: [0, 40] }),
  w({ id: "retro-arcade-sting", title: "Retro Arcade Sting", type: "motion", creatorId: "marcus-cole", price: 60, tags: ["Retro", "Vaporwave", "Pop Art"], views: 3300, createdAt: "2026-09-25", license: "standard", commercial: true, hues: [300, 50] }),
];

export interface Collection { id: string; name: string; description: string; workIds: string[] }
export const collections: Collection[] = [
  { id: "brand-campaign-essentials", name: "Brand Campaign Essentials", description: "Commercially cleared hero assets for launches.", workIds: ["neon-tokyo-dreams", "cosmic-product-shot", "couture-in-motion", "broadcast-motion-id"] },
  { id: "free-starter-kit", name: "Free Starter Kit", description: "Everything free to download and remix.", workIds: ["liquid-gold-portrait", "cinematic-score-ascend", "ai-fashion-lookbook", "talking-character-ad", "floating-isles"] },
  { id: "retro-futures", name: "Retro Futures", description: "Nostalgia filtered through generative tools.", workIds: ["character-lock-series", "style-transfer-pack", "retro-arcade-sting"] },
  { id: "quiet-luxury", name: "Quiet Luxury", description: "Minimal, refined and premium.", workIds: ["liquid-gold-portrait", "chrome-relic", "fluid-brand-loop", "couture-in-motion"] },
];

export const openBriefsSeed = [
  { id: "seed-1", title: "30s launch film for EV brand", type: "video" as WorkType, budget: 2500, style: "Cinematic, Futuristic", license: "commercial" as LicenseType, deadline: "2026-11-15", description: "Hero film for a new electric SUV launch. Night city, reflective surfaces.", owner: "Volt Motors", proposals: 4, createdAt: "2026-10-09" },
  { id: "seed-2", title: "Album cover series (x3)", type: "image" as WorkType, budget: 600, style: "Surreal, Dreamcore", license: "standard" as LicenseType, deadline: "2026-10-30", description: "Three linked covers for an indie electronic EP.", owner: "Halo Records", proposals: 9, createdAt: "2026-10-07" },
  { id: "seed-3", title: "Podcast intro score", type: "music" as WorkType, budget: 300, style: "Noir, Minimal", license: "standard" as LicenseType, deadline: "2026-11-02", description: "12-second intro and outro for a true-crime podcast.", owner: "Case File Media", proposals: 2, createdAt: "2026-10-11" },
];

export const getCreator = (id: string) => creators.find((c) => c.id === id);
export const getWork = (id: string) => works.find((x) => x.id === id);
export const worksBy = (creatorId: string) => works.filter((x) => x.creatorId === creatorId);
export const formatPrice = (p: number) => (p === 0 ? "FREE" : `PREMIUM · $${p}`);
