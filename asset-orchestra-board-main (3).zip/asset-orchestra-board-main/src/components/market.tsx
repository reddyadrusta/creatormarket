import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, Star, MapPin, BadgeCheck, Play, Music, Box, Sparkles, Menu, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { getCreator, formatPrice, TYPE_LABEL, type Creator, type Work } from "@/lib/data";
import { useStore } from "@/lib/store";

export function Art({ hues, type, className = "" }: { hues: [number, number]; type?: string; className?: string }) {
  const Icon = type === "music" ? Music : type === "3d" ? Box : type === "video" || type === "animation" || type === "motion" ? Play : Sparkles;
  return (
    <div className={`relative overflow-hidden ${className}`}
      style={{ background: `radial-gradient(circle at 30% 30%, oklch(0.75 0.18 ${hues[0]}), transparent 60%), radial-gradient(circle at 75% 70%, oklch(0.55 0.2 ${hues[1]}), transparent 55%), oklch(0.18 0.03 ${hues[1]})` }}>
      <div className="absolute inset-0 opacity-30 mix-blend-overlay" style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent 0 6px, oklch(1 0 0 / 0.08) 6px 7px)" }} />
      <Icon className="absolute bottom-3 right-3 h-5 w-5 text-foreground/80" />
    </div>
  );
}

export function WishButton({ id }: { id: string }) {
  const { wishlist, update } = useStore();
  const on = wishlist.includes(id);
  return (
    <button aria-label={on ? "Remove from wishlist" : "Add to wishlist"}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); update((s) => ({ ...s, wishlist: on ? s.wishlist.filter((x) => x !== id) : [...s.wishlist, id] })); toast(on ? "Removed from wishlist" : "Saved to wishlist"); }}
      className="rounded-full bg-background/70 p-2 backdrop-blur transition hover:bg-background">
      <Heart className={`h-4 w-4 ${on ? "fill-primary text-primary" : "text-foreground"}`} />
    </button>
  );
}

export function WorkCard({ work }: { work: Work }) {
  const c = getCreator(work.creatorId)!;
  return (
    <Link to="/work/$id" params={{ id: work.id }} className="group block">
      <div className="relative">
        <Art hues={work.hues} type={work.type} className="aspect-[4/5] rounded-xl transition duration-500 group-hover:scale-[1.02]" />
        <span className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[10px] font-bold tracking-widest ${work.price ? "bg-primary text-primary-foreground" : "bg-background/80 text-foreground"}`}>{formatPrice(work.price)}</span>
        <div className="absolute right-3 top-3"><WishButton id={work.id} /></div>
      </div>
      <h3 className="mt-3 font-display text-lg font-semibold">{work.title}</h3>
      <p className="text-sm text-muted-foreground">{TYPE_LABEL[work.type]} · {c.name}</p>
      <div className="mt-2 flex flex-wrap gap-1.5">{work.tags.map((t) => <span key={t} className="rounded-full border border-border px-2 py-0.5 text-xs text-muted-foreground">{t}</span>)}</div>
    </Link>
  );
}

export function CreatorCard({ c }: { c: Creator }) {
  return (
    <Link to="/creator/$id" params={{ id: c.id }} className="block rounded-2xl border border-border bg-card p-5 transition hover:border-primary/60">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-full" style={{ background: `conic-gradient(oklch(0.7 0.18 ${c.hue}), oklch(0.5 0.2 ${c.hue + 60}), oklch(0.7 0.18 ${c.hue}))` }} />
        <div>
          {c.verified && <span className="inline-flex items-center gap-1 text-xs text-primary"><BadgeCheck className="h-3.5 w-3.5" />Verified</span>}
          <h3 className="font-display font-semibold">{c.name}</h3>
        </div>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">{c.title}</p>
      <div className="mt-2 flex gap-4 text-sm"><span className="inline-flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-primary text-primary" />{c.rating.toFixed(1)}</span><span className="inline-flex items-center gap-1 text-muted-foreground"><MapPin className="h-3.5 w-3.5" />{c.location}</span></div>
      <p className="mt-3 line-clamp-3 text-sm text-muted-foreground">{c.bio}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">{[...c.tools, ...c.specialties].map((t) => <span key={t} className="rounded-full bg-secondary px-2 py-0.5 text-xs">{t}</span>)}</div>
    </Link>
  );
}

export function Section({ title, sub, to, search, children }: { title: string; sub?: string; to?: string; search?: Record<string, string>; children: ReactNode }) {
  return (
    <section className="mx-auto max-w-7xl px-5 py-12">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div><h2 className="font-display text-3xl font-bold">{title}</h2>{sub && <p className="mt-1 text-muted-foreground">{sub}</p>}</div>
        {to && <Link to={to} search={search} className="text-sm font-medium text-primary hover:underline">View all →</Link>}
      </div>
      {children}
    </section>
  );
}

export function PageHeader({ title, sub, children }: { title: string; sub?: string; children?: ReactNode }) {
  return (
    <div className="border-b border-border">
      <div className="mx-auto max-w-7xl px-5 py-12">
        <h1 className="font-display text-4xl font-bold md:text-5xl">{title}</h1>
        {sub && <p className="mt-2 max-w-2xl text-muted-foreground">{sub}</p>}
        {children}
      </div>
    </div>
  );
}

const NAV = [
  { to: "/explore", label: "Explore" }, { to: "/browse", label: "Creators" }, { to: "/collections", label: "Collections" },
  { to: "/licensing", label: "Licensing" }, { to: "/wishlist", label: "Wishlist" }, { to: "/categories", label: "Categories" },
] as const;

export function Header() {
  const { user, update } = useStore();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-5">
        <Link to="/" className="font-display text-xl font-bold tracking-tight">Creator<span className="text-primary">Market</span></Link>
        <nav className="hidden flex-1 gap-5 md:flex">{NAV.map((n) => <Link key={n.to} to={n.to} className="text-sm text-muted-foreground hover:text-foreground" activeProps={{ className: "text-foreground" }}>{n.label}</Link>)}</nav>
        <div className="ml-auto hidden items-center gap-3 md:flex">
          {user ? (<>
            <Link to="/dashboard" className="text-sm hover:text-primary">Dashboard</Link>
            <button onClick={() => { update((s) => ({ ...s, user: null })); toast("Logged out"); nav({ to: "/" }); }} className="rounded-full border border-border px-4 py-1.5 text-sm hover:bg-secondary">Log out</button>
          </>) : (<>
            <Link to="/login" className="text-sm hover:text-primary">Log in</Link>
            <Link to="/register" className="rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground">Join</Link>
          </>)}
        </div>
        <button className="ml-auto md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <div className="flex flex-col gap-3 border-t border-border px-5 py-4 md:hidden" onClick={() => setOpen(false)}>
          {NAV.map((n) => <Link key={n.to} to={n.to}>{n.label}</Link>)}
          {user ? <><Link to="/dashboard">Dashboard</Link><button className="text-left" onClick={() => update((s) => ({ ...s, user: null }))}>Log out</button></> : <><Link to="/login">Log in</Link><Link to="/register">Join</Link></>}
        </div>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-16 border-t border-border">
      <div className="mx-auto grid max-w-7xl gap-8 px-5 py-12 md:grid-cols-3">
        <div><div className="font-display text-xl font-bold">Creator<span className="text-primary">Market</span></div><p className="mt-2 text-sm text-muted-foreground">The AI-native marketplace connecting generative creators with brands and agencies.</p></div>
        <div><h4 className="mb-3 font-semibold">Explore</h4><ul className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
          <li><Link to="/browse">Browse creators</Link></li><li><Link to="/explore">Explore works by mood</Link></li><li><Link to="/moodboard">Moodboard Studio</Link></li><li><Link to="/wishlist">Wishlist</Link></li><li><Link to="/briefs">Open briefs</Link></li><li><Link to="/dashboard">Dashboard</Link></li><li><Link to="/help">Help center</Link></li><li><Link to="/licensing">Compare licenses</Link></li>
        </ul></div>
        <div><h4 className="mb-3 font-semibold">Trust & licensing</h4><p className="text-sm text-muted-foreground">Every portfolio piece declares its tools, workflow, license type and commercial-use status. Verified creators carry reviewed identity and workflow checks.</p></div>
      </div>
      <p className="pb-8 text-center text-xs text-muted-foreground">© 2026 Creator Market</p>
    </footer>
  );
}

export function RequireAuth({ children }: { children: ReactNode }) {
  const { user, hydrated } = useStore();
  if (!hydrated) return <div className="p-20 text-center text-muted-foreground">Loading…</div>;
  if (!user) return (
    <div className="mx-auto max-w-md p-20 text-center">
      <h2 className="font-display text-2xl font-bold">Log in to continue</h2>
      <p className="mt-2 text-muted-foreground">You need an account to use this page.</p>
      <div className="mt-6 flex justify-center gap-3"><Link to="/login" className="rounded-full bg-primary px-5 py-2 font-semibold text-primary-foreground">Log in</Link><Link to="/register" className="rounded-full border border-border px-5 py-2">Join</Link></div>
    </div>
  );
  return <>{children}</>;
}

export const inputCls = "w-full rounded-lg border border-input bg-card px-3 py-2 text-sm outline-none focus:border-primary";
export const btnCls = "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-50";
export const btnGhost = "inline-flex items-center justify-center gap-2 rounded-full border border-border px-5 py-2 text-sm transition hover:bg-secondary";
